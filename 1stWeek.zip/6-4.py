def containsX(string):
    for i in string:
        if i == "X":
            return True
    return False
print(containsX("APPXLE"))